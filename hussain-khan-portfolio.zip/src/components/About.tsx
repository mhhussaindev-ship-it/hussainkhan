"use client";

import { motion } from "framer-motion";
import { MapPin, Calendar, GraduationCap } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="relative py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-14"
        >
          <span className="text-accent-2 text-sm font-semibold tracking-widest">
            WHO I AM
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold mt-2">
            About <span className="gradient-text">Me</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-5 gap-10 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="md:col-span-3 space-y-4 text-muted leading-relaxed"
          >
            <p>
              Hi, I&apos;m <span className="text-text font-medium">M. Hussain Khan</span> —
              a 20-year-old, self-taught web developer from Shahdadpur, Sindh,
              Pakistan. I build clean, responsive websites using{" "}
              <span className="text-text">JavaScript, Next.js, React, Tailwind CSS,
              HTML, CSS</span>, and{" "}
              <span className="text-text">WordPress</span>.
            </p>
            <p>
              My journey started with curiosity about how websites work, and grew
              into a real passion for turning ideas into fast, modern, well-designed
              web experiences — from simple landing pages to full multi-page
              business websites.
            </p>
            <p>
              Alongside development, I also help run my family&apos;s business,{" "}
              <span className="text-text font-medium">Khan Boring Service</span> — a
              borewell drilling and water solutions company based in Shahdadpur. I
              designed and built the company&apos;s own website from the ground up,
              which is now live and helping the business reach more customers
              online. You can read more about that in the{" "}
              <a href="#work" className="text-accent-2 hover:underline">
                Boring Business
              </a>{" "}
              section below.
            </p>

            <div className="flex flex-wrap gap-6 pt-4 text-sm">
              <div className="flex items-center gap-2">
                <Calendar size={16} className="text-accent-2" />
                Age: 20
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-accent-2" />
                Shahdadpur, Sindh, Pakistan
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="md:col-span-2 rounded-2xl border border-border bg-card p-6"
          >
            <div className="flex items-center gap-2 mb-5">
              <GraduationCap size={20} className="text-accent-2" />
              <h3 className="font-semibold text-lg">Education</h3>
            </div>
            <div className="space-y-5">
              <div className="border-l-2 border-accent pl-4">
                <span className="text-xs text-accent-2 font-medium">2021</span>
                <p className="font-medium mt-1">Matriculation (Science)</p>
                <p className="text-sm text-muted">Your School Name Here</p>
              </div>
              <div className="border-l-2 border-accent-2 pl-4">
                <span className="text-xs text-accent-2 font-medium">2023</span>
                <p className="font-medium mt-1">Intermediate / BSc</p>
                <p className="text-sm text-muted">Your College / University Here</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
